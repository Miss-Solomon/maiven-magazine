<?php
if ( ! defined( 'ABSPATH' ) ) exit;







add_action('widgets_init','minerva_category_widget_new');


function minerva_category_widget_new(){
		register_widget("minerva_category_list_widget_imgg");
}

class minerva_category_list_widget_imgg extends WP_Widget {


	function __construct() {
        $widget_opt = array(
            'classname'		 => 'minerva-category-list',
            'description'	 => esc_html__('Theme Category List','minerva-extra')
        );

        parent::__construct( 'minerva_category_list_widget_imgg', esc_html__( 'Minerva Category List', 'minerva-extra' ), $widget_opt );
    }

	
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		$theme_cat_markup ='<div class="category_image_wrapper"><div class="theme_cat_custom_list">';
		
		//if ( ! empty( $instance['minerva_title'] ) ) {
			//echo $args['before_title'] . apply_filters( 'widget_title', $instance['minerva_title'] ) . $args['after_title'];
		//}
		
		if(isset($instance['minerva_taxonomy_itemm'])){
			$theme_cat_markup .='<div class="theme-custom-category-lists theme_img_cat_Itemlist cat-custom-wrap-slider">';
				$args_val = array( 'hide_empty=0' );				
				$excludeCat= $instance['minerva_selected_categories'] ? $instance['minerva_selected_categories'] : '';
				$minerva_select_cat_item= $instance['minerva_select_cat_item'] ? $instance['minerva_select_cat_item'] : '';
				if($excludeCat && $minerva_select_cat_item!='')
				$args_val[$minerva_select_cat_item] = $excludeCat;
				
				$terms = get_terms( $instance['minerva_taxonomy_itemm'], $args_val );
				
				if ( !empty($terms) ) {	

					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						
						if ( is_wp_error( $term_link ) ) {
						continue;
						}
						
					$active_cat_class='';	
					$category_image = '';
					if($term->taxonomy=='category' && is_category())
					{
                 $thisCat = get_category(get_query_var('cat'),false);
              
                
					  if($thisCat->term_id == $term->term_id)
						$active_cat_class='class="active-cat img_cat_item_list_Single"';
				    }
					 
					if(is_tax())
					{
					    $currentTermType = get_query_var( 'taxonomy' );
					    $termId= get_queried_object()->term_id;
						 if(is_tax($currentTermType) && $termId==$term->term_id)
                    $active_cat_class='class="active-cat img_cat_item_list_Single"';
                    
					}
                  
				$category_featured_thumbnail = get_term_meta($term->term_id, 'minerva', true);
				$catImg = !empty( $category_featured_thumbnail['cat-bg'] )? $category_featured_thumbnail['cat-bg'] : '';
				$category_image = 'style="background-image:url('.esc_url( $catImg ).');"';
				 
						$theme_cat_markup .='<div class="cat-custom-wrap-box"><div class="cat-custom-wrap"><a '.wp_kses_post($category_image).' href="' . esc_url( $term_link ) . '" class="category_image_single"></a><div class="cat-inner-list cat-list-inner-content"><a href="' . esc_url( $term_link ) . '"><span class="cat-name-single">' . $term->name ;

						$theme_cat_markup .='</a></span><span class="category-number">'.$term->count.' Articles</span></div>';
						
						
						$theme_cat_markup .='</div></div>';
					}
				}
			$theme_cat_markup .='</div>';
			
			}	
		$theme_cat_markup .='</div></div>';

		echo wp_kses_post($theme_cat_markup);
		echo $args['after_widget'];
	}


	public function form( $instance ) {
		//$minerva_title 				= ! empty( $instance['minerva_title'] ) ? $instance['minerva_title'] : esc_html__( 'Theme Categories List', 'minerva-extra' );

		$minerva_taxonomy_itemm 			= ! empty( $instance['minerva_taxonomy_itemm'] ) ? $instance['minerva_taxonomy_itemm'] : esc_html__( 'category', 'minerva-extra' );
		$minerva_selected_categories 	= (! empty( $instance['minerva_selected_categories'] ) && ! empty( $instance['minerva_select_cat_item'] ) ) ? $instance['minerva_selected_categories'] : array();
		$minerva_select_cat_item 			= ! empty( $instance['minerva_select_cat_item'] ) ? $instance['minerva_select_cat_item'] : '';
		?>
		
		

		
		
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'minerva_taxonomy_itemm' ) ); ?>"><?php _e( esc_attr( 'Select Taxonomy Type:' ) ); ?></label> 
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'minerva_taxonomy_itemm' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'minerva_taxonomy_itemm' ) ); ?>">
					<?php 
					$args = array(
					  'public'   => true,
					  '_builtin' => false
					  
					); 
					$output = 'names'; 
					$operator = 'and';
					$taxonomies = get_taxonomies( $args, $output, $operator ); 
					array_push($taxonomies,'category');
					if ( !empty($taxonomies) ) {
					foreach ( $taxonomies as $taxonomy ) {

						echo '<option value="'.$taxonomy.'" '.selected($taxonomy,$minerva_taxonomy_itemm).'>'.$taxonomy.'</option>';
					}
					}

				?>    
		</select>
		</p>
		
		<p>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'minerva_select_cat_item' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'minerva_select_cat_item' ) ); ?>">
           <option value="" <?php selected($minerva_select_cat_item,'' )?> > <?php echo esc_html__('Show All Category','minerva-extra').' :'; ?> </option>       
           <option value="include" <?php selected($minerva_select_cat_item,'include' )?> > <?php echo esc_html__("Choose Category:","minerva-extra"); ?> </option>       
           <option value="exclude" <?php selected($minerva_select_cat_item,'exclude' )?> > <?php echo esc_html__("Exclude Category","minerva-extra").' :'; ?> </option>
		</select> 
		<select class="widefat minerva-category-widget" id="<?php echo esc_attr( $this->get_field_id( 'minerva_selected_categories' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'minerva_selected_categories' ) ); ?>[]" multiple>
					<?php 			
					if($minerva_taxonomy_itemm){
					$args = array( 'hide_empty=0' );
					$terms = get_terms( $minerva_taxonomy_itemm, $args );
			        echo '<option value="" '.selected(true, in_array('',$minerva_selected_categories), false).'>'.esc_html('None ','minerva-extra').'</option>';
					if ( !empty($terms) ) {
					foreach ( $terms as $term ) {
						echo '<option value="'.$term->term_id.'" '.selected(true, in_array($term->term_id,$minerva_selected_categories), false).'>'.$term->name.'</option>';
					}
				    	
					}
				}

				?>    
		</select>
		</p>
		
		
		<?php 
	}

	
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		//$instance['minerva_title'] 					= ( ! empty( $new_instance['minerva_title'] ) ) ? strip_tags( $new_instance['minerva_title'] ) : '';

		$instance['minerva_taxonomy_itemm'] 			= ( ! empty( $new_instance['minerva_taxonomy_itemm'] ) ) ? strip_tags( $new_instance['minerva_taxonomy_itemm'] ) : '';
		$instance['minerva_selected_categories'] 	= ( ! empty( $new_instance['minerva_selected_categories'] ) ) ? $new_instance['minerva_selected_categories'] : '';
		$instance['minerva_select_cat_item'] 			= ( ! empty( $new_instance['minerva_select_cat_item'] ) ) ? $new_instance['minerva_select_cat_item'] : '';
		
		
		return $instance;
		
		
	}
}





