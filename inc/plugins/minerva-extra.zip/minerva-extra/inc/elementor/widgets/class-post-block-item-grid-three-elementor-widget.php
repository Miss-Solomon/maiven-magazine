<?php

/**
 * Elementor Widget
 * @package Minerva
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class minerva_post_block_item_grid_three extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'posts-block-item-grid-three';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Post Blocks Grid Three', 'minerva-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'minerva_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {
		$this->layout_options();		
		$this->post_query_options();	
		$this->meta_options();	
		$this->design_options();
	}
	
	/**
    * Layout Options
    */
    private function layout_options() {
	
	
		$this->start_controls_section(
            'layout_option',
            [
                'label' => __( 'Layout Options', 'minerva-extra' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		
		$this->add_control(
            'display_top_title_bar',
            [
                'label' => esc_html__('Display Top Title and Button', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'no',
            ]
        );


		$this->add_control(
			'post_col_block_title',
			[
				'label' => __( 'Section Title', 'finmag-extra' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'STAFF PICKS', 'finmag-extra' ),
				'placeholder' => __( 'Type Your title here', 'finmag-extra' ),
			]
		);

		$this->add_control(
            'btn_text', [
                'label' => esc_html__('Button Text', 'senatory-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('VIEW ALL', 'senatory-core'),
                'description' => esc_html__('Enter button text', 'senatory-core'),
            ]
        );

		$this->add_control(
            'btn_link', [
                'label' => esc_html__('Button URL', 'senatory-core'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ],
                'description' => esc_html__('Enter button url', 'senatory-core'),
            ]
        );

		$this->add_control(
            'grid_post_column',
            [
                'label'     =>esc_html__( 'Select Grid Column', 'minerva-extra' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'col-xl-6 col-md-12',
                'options'   => [
                        'col-xl-6 col-md-12'    =>esc_html__( '2 Columns', 'minerva-extra' ),
                        'col-xl-4 col-md-12'    =>esc_html__( '3 Columns', 'minerva-extra' ),
                        'col-xl-3 col-md-12'    =>esc_html__( '4 Columns', 'minerva-extra' ),
                    ],
            ]
        );

		$this->add_responsive_control(
			'post_block_list_img_height',
			[
				'label' =>esc_html__( 'Set Post Image height', 'minerva-extra' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 522,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 522,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' =>400,
					'unit' => 'px',
				],
				
				'default'  => [
					'unit' => 'px',
					'size' => 522,
				],
				
				'selectors' => [
					'{{WRAPPER}} .post-block-column-wrapper-three .post-block-style-one-inner .post-block-media-wrap a img' => 'height: {{SIZE}}{{UNIT}}!important;',
				],
			]
		);			
		
		
		$this->end_controls_section();
	
	}
	
	/**
    * Post Query Options
    */
    private function post_query_options() {
	
	
		$this->start_controls_section(
            'post_query_option',
            [
                'label' => __( 'Post Options', 'minerva-extra' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		
		
		// Post Sort
		
        $this->add_control(
            'post_sorting',
            [
                'type'    => \Elementor\Controls_Manager::SELECT2,
                'label' => esc_html__('Post Sorting', 'minerva-extra'),
                'default' => 'date',
                'options' => [
					'date' => esc_html__('Recent Post', 'minerva-extra'),
                    'rand' => esc_html__('Random Post', 'minerva-extra'),
					'title'         => __( 'Title Sorting Post', 'minerva-extra' ),
                    'modified' => esc_html__('Last Modified Post', 'minerva-extra'),
                    'comment_count' => esc_html__('Most Commented Post', 'minerva-extra'),
					
                ],
            ]
        );		
		
		// Post Order
		
        $this->add_control(
            'post_ordering',
            [
                'type'    => \Elementor\Controls_Manager::SELECT2,
                'label' => esc_html__('Post Ordering', 'minerva-extra'),
                'default' => 'DESC',
                'options' => [
					'DESC' => esc_html__('Desecending', 'minerva-extra'),
                    'ASC' => esc_html__('Ascending', 'minerva-extra'),
                ],
            ]
        );
		
		
		// Post Categories
		
		$this->add_control(
            'post_categories',
            [
                'type'      => \Elementor\Controls_Manager::SELECT2,
				'label' =>esc_html__('Select Categories', 'minerva-extra'),
                'options'   => $this->posts_cat_list(),
                'label_block' => true,
                'multiple'  => true,
            ]
        );
	
		$this->add_control(
			'post_tags',
			[
				'label'       => esc_html__('Select Tags', 'minerva-extra'),
				'type'      => \Elementor\Controls_Manager::SELECT2,
				'options'     => minerva_post_tags(),
				'label_block' => true,
				'multiple'    => true,
			]
		);
		
		
		// Post Items.
		
        $this->add_control(
            'post_number',
			[
				'label'         => esc_html__( 'Number Of Posts', 'minerva-extra' ),
				'type'          => \Elementor\Controls_Manager::NUMBER,
				'default'       => '2',
			]
        );
		
		$this->add_control(
            'enable_offset_post',
            [
               'label' => esc_html__('Enable Skip Post', 'minerva-extra'),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'label_on' => esc_html__('Yes', 'minerva-extra'),
               'label_off' => esc_html__('No', 'minerva-extra'),
               'default' => 'no',
               
            ]
        );
      
        $this->add_control(
			'post_offset_count',
			  [
			   'label'         => esc_html__( 'Skip Post Count', 'minerva-extra' ),
			   'type'          => \Elementor\Controls_Manager::NUMBER,
			   'default'       => '1',
			   'condition' => [ 'enable_offset_post' => 'yes' ]

			  ]
        );

        // Specific Posts by ID.
        $this->add_control(
            'post_ids',
            [
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label'       => __( 'Show specific posts by ID', 'minerva-extra' ),
                'placeholder' => __( 'ex.: 256, 54, 78', 'minerva-extra' ),
                'description'   => __( 'Paste post ID\'s separated by commas. To find ID, click edit post and you\'ll find it in the browser address bar', 'minerva-extra' ),
                'default'     => '',
                'separator'     => 'before',
                'label_block' => true,
            ]
        );
		
		
		$this->end_controls_section();
	
	}	
	
	/**
    * Meta Options
    */
    private function meta_options() {
	
	
		$this->start_controls_section(
            'meta_option',
            [
                'label' => __( 'Meta Options', 'minerva-extra' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		
		$this->add_control(
            'display_excerpt',
            [
                'label' => esc_html__('Display Post Excerpt', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		$this->add_control(
            'display_post_block_meta',
            [
                'label' => esc_html__('Display Block Top Metalist', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		
     	$this->add_control(
            'display_cat',
            [
                'label' => esc_html__('Display Category Name', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		$this->add_control(
            'display_date',
            [
                'label' => esc_html__('Display Date', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		$this->add_control(
         	'display_author',
         	[
				 'label' => esc_html__('Display Author', 'minerva-extra'),
				 'type' => \Elementor\Controls_Manager::SWITCHER,
				 'label_on' => esc_html__('Yes', 'minerva-extra'),
				 'label_off' => esc_html__('No', 'minerva-extra'),
				 'default' => 'yes',
         	]
     	);
		
		$this->add_control(
            'display_view',
            [
                'label' => esc_html__('Display View Count', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
	

        $this->add_control(
            'display_read',
            [
                'label' => esc_html__('Display Read Time', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		 $this->add_control(
            'display_view_btn',
            [
                'label' => esc_html__('Display View Button', 'minerva-extra'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		
		$this->add_control(
            'view_btn_text', [
                'label' => esc_html__('Button Text', 'senatory-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('View Topic', 'senatory-core'),
                'description' => esc_html__('Enter button text', 'senatory-core'),
            ]
        );
		
		
	
		$this->end_controls_section();
	
	}	
	
	/**
    * Design Options
    */
    private function design_options() {
	
	
		$this->start_controls_section(
            'design_option',
            [
                'label' => __( 'Typography', 'minerva-extra' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		
		$this->add_group_control(
           \Elementor\Group_Control_Typography::get_type(),
           [
              'name' => 'post_block_top_title',
              'label' => esc_html__( 'Top Title Typography', 'minerva-extra' ),
              'selector' => '{{WRAPPER}} .post-block-column-wrapper-three .post-blocks-column-title h2.post-block-title',
           ]
        );

		$this->add_group_control(
           \Elementor\Group_Control_Typography::get_type(),
           [
              'name' => 'post_block_list_title',
              'label' => esc_html__( 'Post Title Typography', 'minerva-extra' ),
              'selector' => '{{WRAPPER}} .post-block-column-wrapper-three article.post-block-style-one-wrapper .post-block-style-one-inner .post-item-title h2.post-title',
           ]
        );	

		

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'post_block_list_excerpt',
				'label' => __( 'Post Excerpt Typography', 'minerva-extra' ),
				'selector' => '{{WRAPPER}} .post-block-column-wrapper-three article.post-block-style-one-wrapper .post-block-style-one-inner .post-excerpt-box p',
			]
		);
		


		$this->add_control(
          'title_length',
          [
            'label'         => esc_html__( 'Post Title Length', 'minerva-extra' ),
            'type'          => \Elementor\Controls_Manager::NUMBER,
            'default'       => '20',
          ]
        );

        $this->add_control(
          'content_length',
          [
            'label'         => esc_html__( 'Post Excerpt Length', 'minerva-extra' ),
            'type'          => \Elementor\Controls_Manager::NUMBER,
            'default'       => '5',
          ]
        );
		

		
		$this->end_controls_section();
	
	}	
		


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

		$string_ID = $settings['post_ids'];
        $post_ID = ( ! empty( $string_ID ) ) ? array_map( 'intval', explode( ',', $string_ID ) ) : '';

		$grid_post_column = $settings['grid_post_column'];

		$title_limit = $settings['title_length'];
		$content_limit = $settings['content_length'];
		$post_count = $settings['post_number'];
		$post_order  = $settings['post_ordering'];
		$post_sortby = $settings['post_sorting']; 

		$display_blog_excerpt = $settings['display_excerpt'];
		$display_blog_cat = $settings['display_cat'];
		$display_blog_author = $settings['display_author'];
		$display_blog_date = $settings['display_date'];
		$display_blog_view = $settings['display_view'];
		$display_blog_read = $settings['display_read'];
		$display_post_block_meta = $settings['display_post_block_meta'];
		
		$display_view_btn = $settings['display_view_btn'];
		
		$display_top_title_bar = $settings['display_top_title_bar'];
		
		$args = [
            'post_type' => 'post',
            'post_status' => 'publish',
			'order' => $settings['post_ordering'],
			'posts_per_page' => $settings['post_number'],
			'tag__in'        => $settings['post_tags'],
			'ignore_sticky_posts' => 1,
			'suppress_filters' => false,
        ];
		
		// Category
        if ( ! empty( $settings['post_categories'] ) ) {
            $args['category_name'] = implode(',', $settings['post_categories']);
        }
		
		// Post Sorting
        if ( ! empty( $settings['post_sorting'] ) ) {
            $args['orderby'] = $settings['post_sorting'];
        }	
		
		// Specific Posts by ID's
        if ( ! empty( $settings['post_ids'] ) ) {
            $args['post__in'] = $post_ID;
        }

		// Post Offset		
		if($settings['enable_offset_post'] == 'yes') {
			$args['offset'] = $settings['post_offset_count'];
		}

		// Query
        $query = new \WP_Query( $args ); ?>
		
		

		
		<?php if ( $query->have_posts() ) : ?>


		<div class="post-block-column-wrapper post-block-column-wrapper-three">

			<?php if($display_top_title_bar=='yes'): ?>	
			<div class="row">
				<div class="col-lg-12">
					<div class="post-blocks-column-title">
						<h2 class="post-block-title"><?php echo wp_kses_post( $settings['post_col_block_title']  ); ?></h2>
					</div>
				</div>
			</div>
			<?php endif; ?>
		
			<div class="row">	

			<?php while ($query->have_posts()) : $query->the_post(); ?>

				<div class="<?php echo esc_attr($grid_post_column);?>">

					
				<article <?php post_class('post-block-style-one-wrapper'); ?>>

				<div class="post-block-style-one-inner">


						<div class="post-block-media-wrap">
							<a href="<?php the_permalink(); ?>">
								<img src="<?php echo esc_attr(esc_url(get_the_post_thumbnail_url(null, 'full'))); ?>" alt="<?php the_title_attribute(); ?>">
							</a>
						</div>
					
						<div class="post-block-content-wrap">
					
								<?php if($display_post_block_meta=='yes'): ?>
								<div class="post-top-meta-list">

								<?php if($display_blog_cat=='yes'): ?>	
								<div class="post-category-box">
								<?php require MINERVA_THEME_DIR . '/template-parts/cat-alt-template.php'; ?>
								</div>
								<?php endif; ?>
								
								<?php if($display_blog_date=='yes'): ?>	
								<div class="post-meta-date-box">
									<?php echo esc_html( get_the_date( 'M j, Y' ) ); ?>
								</div>
								<?php endif; ?>
								
								<?php if($display_blog_author =='yes'): ?> 
								<div class="post-meta-author-box">
									By <?php echo get_the_author_link(); ?>
								</div>
								<?php endif; ?>
								
								<?php if($display_blog_view=='yes'): ?>	
				                <div class="post-view-box">
				                    <?php minerva_set_post_view();?>
									<?php echo minerva_get_post_view(); ?>

				                    Views
				                </div>
								<?php endif; ?>
								
								<?php if($display_blog_read=='yes'): ?>	
				                <div class="read-time-box">
				                    <?php echo minerva_reading_time(); ?>
				                </div>
								<?php endif; ?>
								

				            	</div>
								<?php endif; ?>
									
								
								<div class="post-item-title">
									<h2 class="post-title">
									<a href="<?php the_permalink(); ?>"><?php echo esc_html( wp_trim_words(get_the_title(), $title_limit,'') ); ?></a>
									</h2>
								</div>
								
								<?php if($display_blog_excerpt =='yes'): ?> 
								<div class="post-excerpt-box">
									<p><?php echo esc_html( wp_trim_words(get_the_excerpt(), $content_limit ,'') );?></p>
								</div>
								<?php endif; ?>	
								
								<?php if($display_view_btn =='yes'): ?>
								<div class="view-topic-btn">
									<a href="<?php the_permalink(); ?>" class="view-btn"><?php echo esc_html($settings['view_btn_text']) ?></a>
								</div>
								<?php endif; ?>	

								
							</div>
			

					</div>
				
				</article>


				</div>


			<?php endwhile; ?>


		</div>

		</div>	
		
		<?php wp_reset_postdata(); ?>
		
		<?php endif; ?>
		

	
	<?php 
}
		
   
   	public function posts_cat_list() {
		
		$terms = get_terms( array(
			'taxonomy'    => 'category',
			'hide_empty'  => true
		) );

		$cat_list = [];
		foreach($terms as $post) {
		$cat_list[$post->slug]  = [$post->name];
		}
		return $cat_list;
	  
	}		
	
}

