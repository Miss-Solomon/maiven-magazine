<?php

/**
 * Elementor Widget
 * @package Minerva
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class minerva_post_tab extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'posts-tab';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Minerva Posts Tab', 'minerva-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-picture-o';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'minerva_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {
		$this->tab_options();		
		$this->post_query_options();	
		$this->meta_options();	
		$this->design_options();
	}
	
	/**
    * Tab Item Options
    */
    private function tab_options() {
	
	
		$this->start_controls_section(
            'tab_option',
            [
                'label' => __( 'Tab Item and Content', 'minerva-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		
		$this->add_control(
			'tabsec_top_title',
			[
				'label' => __( 'Section Title', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Latest Articles', 'plugin-domain' ),
				'placeholder' => __( 'Discover articles in all topics', 'plugin-domain' ),
			]
		);


		$this->add_control(
			'tabsec_top_subtitle',
			[
				'label' => __( 'Section Sub Title', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Text Description', 'plugin-domain' ),
				'placeholder' => __( 'Type Your Sub title here', 'plugin-domain' ),
			]
		);


		
		$this->add_control(
         'tabs',
         [
             'label' => esc_html__('Tab Items', 'minerva-extra'),
             'type' => Controls_Manager::REPEATER,
             'default' => [
                 [
                     'tab_title' => esc_html__('Add Tab Item Menu', 'minerva-extra'),
                 ],
             ],
			 
             'fields' => [
			 
                [   'name' => 'post_categories',
                     'label' =>esc_html__('Select Categories', 'minerva-extra'),
                     'type'      => Controls_Manager::SELECT2,
                     'options'   => $this->posts_cat_list(),
                     'label_block' => true,
                     'multiple'  => true,
					 'placeholder' => __( 'All Categories', 'minerva-extra' ),
                ],
				 
                [   'name' => 'tab_menu_name',
                     'label'         => esc_html__( 'Tab Menu Name', 'minerva-extra' ),
                     'type'          => Controls_Manager::TEXT,
                     'default'       => 'Add Tab Menu',
                ],
			   
                [   
                  'name' => 'enable_offset_post',
                  'label'         => esc_html__( 'Enable Skip Post', 'minerva-extra' ),
                  'type' => Controls_Manager::SWITCHER,
                  'label_on' => esc_html__('Yes', 'minerva-extra'),
                  'label_off' => esc_html__('No', 'minerva-extra'),
				  'default' => 'no',
                ],
			   
                [  
                   'name' => 'post_offset_count',
                   'label'         => esc_html__( 'Skip Post Count', 'minerva-extra' ),
                   'type'          => Controls_Manager::NUMBER,
                   'default'       => '1',
                   'condition' => [ 'enable_offset_post' => 'yes' ]
                ],
			   
             ],
         ]
     );
				
		
		$this->end_controls_section();
	
	}
	
	/**
    * Post Query Options
    */
    private function post_query_options() {
	
	
		$this->start_controls_section(
            'post_query_option',
            [
                'label' => __( 'Post Options', 'minerva-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		
		// Post Items
		
        $this->add_control(
            'post_number',
			[
				'label'         => esc_html__( 'Number Of Posts', 'minerva-extra' ),
				'type'          => Controls_Manager::NUMBER,
				'default'       => '1',
			]
        );
		
		
		// Post Sort
		
        $this->add_control(
            'post_sorting',
            [
                'type'    => Controls_Manager::SELECT2,
                'label' => esc_html__('Post Sorting', 'minerva-extra'),
                'default' => 'date',
                'options' => [
					'date' => esc_html__('Recent Post', 'minerva-extra'),
                    'rand' => esc_html__('Random Post', 'minerva-extra'),
					'title'         => __( 'Title Sorting Post', 'minerva-extra' ),
                    'modified' => esc_html__('Last Modified Post', 'minerva-extra'),
                    'comment_count' => esc_html__('Most Commented Post', 'minerva-extra'),
					
                ],
            ]
        );		
		
		// Post Order
		
        $this->add_control(
            'post_ordering',
            [
                'type'    => Controls_Manager::SELECT2,
                'label' => esc_html__('Post Ordering', 'minerva-extra'),
                'default' => 'DESC',
                'options' => [
					'DESC' => esc_html__('Desecending', 'minerva-extra'),
                    'ASC' => esc_html__('Ascending', 'minerva-extra'),
                ],
            ]
        );

		
		$this->end_controls_section();
	
	}	
	
	/**
    * Meta Options
    */
    private function meta_options() {
	
	
		$this->start_controls_section(
            'meta_option',
            [
                'label' => __( 'Meta Options', 'minerva-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		
		$this->add_control(
            'display_cat',
            [
                'label' => esc_html__('Display Category Name', 'minerva-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		$this->add_control(
            'display_excerpt_large',
            [
                'label' => esc_html__('Display Post Excerpt Large', 'ennlil-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'ennlil-extra'),
                'label_off' => esc_html__('No', 'ennlil-extra'),
                'default' => 'yes',
            ]
        );
		
		$this->add_control(
            'display_excerpt',
            [
                'label' => esc_html__('Display Post Excerpt', 'ennlil-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'ennlil-extra'),
                'label_off' => esc_html__('No', 'ennlil-extra'),
                'default' => 'yes',
            ]
        );

		$this->add_control(
         	'display_author',
         	[
				 'label' => esc_html__('Display Author', 'minerva-extra'),
				 'type' => Controls_Manager::SWITCHER,
				 'label_on' => esc_html__('Yes', 'minerva-extra'),
				 'label_off' => esc_html__('No', 'minerva-extra'),
				 'default' => 'yes',
         	]
     	);
		
		$this->add_control(
            'display_date',
            [
                'label' => esc_html__('Display Date', 'minerva-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'yes',
            ]
        );
		
		$this->add_control(
            'display_read_time',
            [
                'label' => esc_html__('Display Post Read Time', 'minerva-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'minerva-extra'),
                'label_off' => esc_html__('No', 'minerva-extra'),
                'default' => 'no',
            ]
        );

	
		$this->end_controls_section();
	
	}	
	
	/**
    * Design Options
    */
    private function design_options() {
	
	
		$this->start_controls_section(
            'design_option',
            [
                'label' => __( 'Design Options', 'minerva-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		

		
			$this->add_responsive_control(
			'tab_grid_img_height',
			[
				'label' =>esc_html__( 'Set Top Big Post Image height', 'minerva-extra' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 300,
					'unit' => 'px',
				],
				
				'default'  => [
					'unit' => 'px',
					'size' => 400,
				],
				
				'selectors' => [
					'{{WRAPPER}} .theme_post_Tab__content.theme_post_Tabone__content .theme_post_Tab__block.block-tab-item .blog-post-grid-wrapper .news-post-grid-thumbnail img' => 'height: {{SIZE}}{{UNIT}}!important;',
				],
			]
		);	


		$this->add_responsive_control(
			'tab_list_img_width',
			[
				'label' =>esc_html__( 'Set Top List Post Image Width', 'minerva-extra' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 165,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 165,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 165,
					'unit' => 'px',
				],
				
				'default'  => [
					'unit' => 'px',
					'size' => 165,
				],
				
				'selectors' => [
					'{{WRAPPER}} .theme_post_Tab__content.theme_post_Tabone__content .post-gridstyle-two.tab-bottom-grid-style .post-grid-wrapper-two-inner .grid-thumbnail-two-wrap' => 'min-width: {{SIZE}}{{UNIT}}!important;',
				],
			]
		);	

		$this->add_responsive_control(
			'tab_list_img_height',
			[
				'label' =>esc_html__( 'Set Top List Post Image Height', 'minerva-extra' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 110,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 110,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 110,
					'unit' => 'px',
				],
				
				'default'  => [
					'unit' => 'px',
					'size' => 110,
				],
				
				'selectors' => [
					'{{WRAPPER}} .theme_post_Tab__content.theme_post_Tabone__content .post-gridstyle-two.tab-bottom-grid-style .post-grid-wrapper-two-inner .grid-thumbnail-two-wrap img' => 'height: {{SIZE}}{{UNIT}}!important;',
				],
			]
		);


		
		$this->add_control(
          'title_length',
          [
            'label'         => esc_html__( 'Big Block Post Title Length', 'minerva-extra' ),
            'type'          => Controls_Manager::NUMBER,
            'default'       => '10',
          ]
        );
		
		$this->add_control(
          'content_length',
          [
            'label'         => esc_html__( 'Post Excerpt Length', 'ennlil-extra' ),
            'type'          => Controls_Manager::NUMBER,
            'default'       => '15',
          ]
        );
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tabsecbig_title_typography',
				'label' => __( 'Section Title Typography', 'minerva-extra' ),
				'selector' => '{{WRAPPER}} .theme-post-tab-wrapper.blog-tab-wrapper .tab-section-title h2',
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tabsecsmall_title_typography',
				'label' => __( 'Small Title Typography', 'minerva-extra' ),
				'selector' => '{{WRAPPER}} .theme-post-tab-wrapper.blog-tab-wrapper .tab-section-title p',
			]
		);
		
		
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tabbedbig_title_typography',
				'label' => __( 'Featured Title Typography', 'minerva-extra' ),
				'selector' => '{{WRAPPER}} .blog-post-tab-wrap.post-block-item .grid-content-bottom h3.post-title',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tabbedsmall_title_typography',
				'label' => __( 'Small Title Typography', 'minerva-extra' ),
				'selector' => '{{WRAPPER}} .tab-small-post-list .tab-post-grid-content-small h3.post-title',
			]
		);
		

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tabbebiggp_content_typography',
				'label' => __( 'Small Paragraph Typography', 'minerva-extra' ),
				'selector' => '{{WRAPPER}} .blog-post-tab-wrap.post-block-item .grid-content-bottom .post-excerpt-box p',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tabbedsmallp_content_typography',
				'label' => __( 'Small Paragraph Typography', 'minerva-extra' ),
				'selector' => '{{WRAPPER}} .tab-small-post-list .tab-post-grid-content-small .post-excerpt-box p',
			]
		);


		$this->add_control('tabone_title_color', [
            'label' => esc_html__('Large Post Title Color', 'senatory-master'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .blog-post-tab-wrap.post-block-item .grid-content-bottom h3.post-title a" => "color: {{VALUE}}"
            ]
        ]);

        $this->add_control('tabsmall_title_color', [
            'label' => esc_html__('Small Post Title Color', 'senatory-master'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .tab-small-post-list .tab-post-grid-content-small h3.post-title a" => "color: {{VALUE}}"
            ]
        ]);

        $this->add_control('tabsmall_content_color', [
            'label' => esc_html__('Post Excerpt Color', 'senatory-master'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .theme_post_Tab__content.theme_post_Tabone__content .post-block-item.tab-style-two-grid .news-post-grid-content .post-excerpt-box p" => "color: {{VALUE}}"
            ]
        ]);

        $this->add_control('tabmeta_one_color', [
            'label' => esc_html__('Large Post Meta Color', 'senatory-master'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .blog-post-grid-wrapper.blog-post-grid-wrapper-four.tab-style-two-grid .post-meta-items div, .blog-post-grid-wrapper-four.tab-style-two-grid .news-post-grid-content .category-box a" => "color: {{VALUE}}"
            ]
        ]);


		$this->end_controls_section();
	
	}	
		


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

		
		$title_limit = $settings['title_length'];
		$content_limit = $settings['content_length'];
		
		$post_number        = $settings['post_number'];
		$post_order         = $settings['post_ordering'];
        $post_sortby        = $settings['post_sorting'];

        $display_blog_excerpt = $settings['display_excerpt']; 
		
		$display_blog_excerpt_lg = $settings['display_excerpt_large'];
		
		$display_blog_cat = $settings['display_cat'];
		$display_blog_author = $settings['display_author'];
		$display_blog_date = $settings['display_date'];

		$display_read_time = $settings['display_read_time'];
		
		$tabs               = $settings['tabs'];
        $post_count         = count($tabs);

	?>


	    <div class="theme-post-tab-wrapper blog-tab-wrapper">
            <div class="post-tab-block-element news_tab_Block">
				
				<div class="tab-section-title">
					<h2><?php echo wp_kses_post( $settings['tabsec_top_title']  ); ?></h2>
					<p><?php echo wp_kses_post( $settings['tabsec_top_subtitle']  ); ?></p>
				</div>
				
				<ul class="nav nav-tabs" role="tablist">
					<?php
						  foreach ( $tabs as $tab_Menu_key=>$value ) {
								   
								if( $tab_Menu_key == 0 ){
									  echo '<li class="nav-item"><a class="nav-link active" href="#'.$this->get_id().$value['_id'].'" data-toggle="tab"><span class="tab_menu_Item">'.$value['tab_menu_name'].'</span></a></li>';
								} else {
									  echo '<li class="nav-item"><a class="nav-link" href="#'.$this->get_id().$value['_id'].'" data-toggle="tab"><span class="tab_menu_Item">'.$value['tab_menu_name'].'</span></a></li>';
								}
							 
						  }
					?>
				</ul>

                    <div class="theme_post_Tab__content theme_post_Tabone__content tab-content">

                     <?php
                     
                     foreach ($tabs as $tab_Content_key=>$value) {
                      
                        if( $tab_Content_key == 0){
                           echo '<div role="tabpanel" class="tab-pane fade active show" id="'.$this->get_id().$value['_id'].'">';
                        } else {
                           echo '<div role="tabpanel" class="tab-pane fade" id="'.$this->get_id().$value['_id'].'">';
                        }
                        
                        $args = array(
                           'post_type'   =>  'post',
                           'post_status' => 'publish',
                           'posts_per_page' => $post_number,
                           'order' => $post_order,
                           'orderby' => $post_sortby,
                           'ignore_sticky_posts' => 1,
                        );
						
						
						// Category
						
						if ( ! empty( $value['post_categories'] ) ) {
							$args['category_name'] = implode(',', $value['post_categories']);
						}
		
						// Post Offset
						
						if($value['enable_offset_post'] == 'yes') {
							$args['offset'] = $value['post_offset_count'];
						}
                   
                   
                       $Tabquery = new \WP_Query( $args );
                     
                     ?>

                     <?php if ( $Tabquery->have_posts() ) : ?>
					 
                        <div class="theme_post_Tab__block block-tab-item">
                            <div class="row">
							  
								<?php while ($Tabquery->have_posts()) : $Tabquery->the_post();?>
								
                                <?php if ( $Tabquery->current_post == 0 ): ?>
								
								<div class="col-lg-6 col-sm-12">
									
								<div class="blog-post-tab-wrap post-block-item">
					        		
									
									<div class="news-post-grid-thumbnail">
					        			<a href="<?php the_permalink(); ?>" class="news-post-grid-thumbnail-wrap">
											<img src="<?php echo esc_attr(esc_url(get_the_post_thumbnail_url(null, 'full'))); ?>" alt="<?php the_title_attribute(); ?>">
										</a>
									</div>
									
									<div class="news-post-grid-content grid-content-bottom">
									
										<?php if($display_blog_cat=='yes'): ?>	
										<div class="slider-category-box tab-cat-box">
										<?php require MINERVA_THEME_DIR . '/template-parts/cat-alt-template.php'; ?>
										</div>
										<?php endif; ?>		

										<h3 class="post-title">
											<a href="<?php the_permalink(); ?>"><?php echo esc_html( wp_trim_words(get_the_title(), $title_limit,'') ); ?></a>
										</h3>
										
										<?php if($display_blog_excerpt_lg =='yes'): ?> 
										<div class="post-excerpt-box">
											<p><?php echo esc_html( wp_trim_words(get_the_excerpt(), $content_limit ,'') );?></p>
										</div>
										<?php endif; ?>	
										
										<div class="slider-post-meta-items tab-large-col-meta">
											<div class="slider-meta-left">

												<div class="slider-meta-left-author">
													<?php echo get_avatar( get_the_author_meta( 'ID' ), 48 ); ?>
												</div>
												
												<div class="slider-meta-left-content">

													<h4 class="post-author-name">
														<?php echo get_the_author_link(); ?>
													</h4>

													<ul class="slider-bottom-meta-list">

														<?php if($display_blog_date=='yes'): ?>

														<li class="slider-meta-date"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></li>

														<?php endif; ?>	

														<?php if($display_read_time=='yes'): ?>

														<li class="slider-meta-time"><?php echo minerva_reading_time(); ?></li>

														<?php endif; ?>	

													</ul>
												</div>
											</div>
											<div class="slider-meta-right">
												<div class="post-fav-box">
													3k
												</div>
												<div class="post-comment-box">
													63
												</div>
											</div>
										</div>
									</div>

								</div>

								</div>
								
                                <?php else: ?>
                                	
                                <?php if ( $Tabquery->current_post == 1 ): ?>
									
                                <div class="col-lg-6 col-sm-12">

                                   <?php endif; ?> 

								<div class="tab-small-list-item tab-bottom-grid-style">

				                <div class="tab-small-post-list">
								
									<div class="tab-small-thumbnail-wrap">
										<a href="<?php the_permalink(); ?>">
											<img src="<?php echo esc_attr(esc_url(get_the_post_thumbnail_url(null, 'full'))); ?>" alt="<?php the_title_attribute(); ?>">
										</a>
									</div>
								
									<div class="tab-post-grid-content-small">
									
										<?php if($display_blog_cat=='yes'): ?>	
										<div class="slider-category-box tab-small-cat-box">
										<?php require MINERVA_THEME_DIR . '/template-parts/cat-alt-template.php'; ?>
										</div>
										<?php endif; ?>		

										<h3 class="post-title">
											<a href="<?php the_permalink(); ?>"><?php echo esc_html( wp_trim_words(get_the_title(), $title_limit,'') ); ?></a>
										</h3>
										
										<?php if($display_blog_excerpt =='yes'): ?> 
										<div class="post-excerpt-box">
											<p><?php echo esc_html( wp_trim_words(get_the_excerpt(), $content_limit ,'') );?></p>
										</div>
										<?php endif; ?>	
										
										<div class="slider-post-meta-items tab-small-col-meta">
											<div class="slider-meta-left">

												<div class="slider-meta-left-author">
													<?php echo get_avatar( get_the_author_meta( 'ID' ), 31 ); ?>
												</div>
												
												<div class="slider-meta-left-content">

													<h4 class="post-author-name">
														<?php echo get_the_author_link(); ?>
													</h4>

													<ul class="slider-bottom-meta-list">

														<?php if($display_blog_date=='yes'): ?>

														<li class="slider-meta-date"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></li>

														<?php endif; ?>	

														<?php if($display_read_time=='yes'): ?>

														<li class="slider-meta-time"><?php echo minerva_reading_time(); ?></li>

														<?php endif; ?>	

													</ul>
												</div>
											</div>
											<div class="slider-meta-right">
												<div class="post-fav-box">
													3k
												</div>
												<div class="post-comment-box">
													63
												</div>
											</div>
										</div>
									</div>
									
								</div>

								</div>
											
                                    <?php if (($Tabquery->current_post + 1) == ($Tabquery->post_count)) { ?>
                           
                                </div>

                                <?php } ?> 
                                <?php endif ?>

                                <?php 
                                endwhile; ?>
								
                              </div>
                           </div>
                        <?php wp_reset_postdata(); ?>
                     <?php endif; ?>
					 
                     </div>
                     <?php } ?>
                </div>
          </div>
      </div>


		
	
	<?php 
	
    }
		
   
   	public function posts_cat_list() {
		
		$terms = get_terms( array(
            'taxonomy'    => 'category',
            'hide_empty'  => true
		) );

      $cat_list = [];
      foreach($terms as $post) {
      	$cat_list[$post->slug]  = [$post->name];
      }
      return $cat_list;
	
	}	
	

}


Plugin::instance()->widgets_manager->register_widget_type( new minerva_post_tab() );